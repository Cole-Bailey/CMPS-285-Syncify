import "./login-page.css";
import "../../App.css";
import axios from "axios";
import React, { useMemo } from "react";
import { ApiResponse } from "../../constants/types";
import { Formik, Form, Field } from "formik";
import { Button, Input } from "semantic-ui-react";
import { useAsyncFn } from "react-use";
import { PageWrapper } from "../../components/page-wrapper/page-wrapper";
import { loginUser } from "../../authentication/authentication-services";
import SyncifyImg from "../../assets/Syncify.png";
import UserCreateModal from "../../modals/user-create/user-create-modal";

const baseUrl = process.env.REACT_APP_API_BASE_URL;

type LoginRequest = {
  userName: string;
  password: string;
};

type LoginResponse = ApiResponse<boolean>;

type FormValues = LoginRequest;

//This is a *fairly* basic form
//The css used in here is a good example of how flexbox works in css
//For more info on flexbox: https://css-tricks.com/snippets/css/a-guide-to-flexbox/
export const LoginPage = () => {
  const initialValues = useMemo<FormValues>(
    () => ({
      userName: "",
      password: "",
    }),
    []
  );
  const [, submitLogin] = useAsyncFn(async (values: LoginRequest) => {
    if (baseUrl === undefined) {
      return;
    }

    const response = await axios.post<LoginResponse>(
      `${baseUrl}/api/authenticate`,
      values
    );

    if (response.data.data) {
      console.log("Successfully Logged In!");
      loginUser();
    }
  }, []);

  return (
    <PageWrapper>
      <div className="flex-box-centered-content-login-page">
        <div className="login-form">
          <Formik initialValues={initialValues} onSubmit={submitLogin}>
            <Form>
              <div>
                <div>
                  <div className="field-label">
                    <label htmlFor="userName">UserName</label>
                  </div>
                  <Field className="field" id="username" name="username">
                    {({ field }) => <Input {...field} />}
                  </Field>
                </div>
                <div>
                  <div className="field-label">
                    <label htmlFor="password">Password</label>
                  </div>
                  <Field className="field" id="password" name="password">
                    {({ field }) => <Input type="password" {...field} />}
                  </Field>
                </div>
                <div className="button-container-login-page">
                  <Button
                    color="blue"
                    icon="user"
                    content="Login"
                    labelPosition="left"
                    type="submit"
                  />
                  <UserCreateModal />
                </div>
              </div>
            </Form>
          </Formik>
        </div>
      </div>
      <div className="center">
        <img src={SyncifyImg} alt="" />
      </div>
    </PageWrapper>
  );
};
